#include <stdio.h>
#include "protocol.h"
#include "support.h"
#include "input.h"
#include "can.h"
#include "led.h"
#include "version.h"
#include "fault.h"
#include "sync.h"
#include "i2c.h"
#include "spi.h"
#include "uart.h"
#include "rs232.h"
#include "rs485.h"

volatile communication_status_t communication_status = {0};

typedef struct
{
    uint8_t active;
    uint8_t sequence;

} uart_tx_transaction_t;

typedef struct
{
    volatile uint8_t ready;
    uint16_t length;
    uint8_t data[RESPONSE_PROTOCOL_MAX_PAYLOAD];

} uart_rx_mailbox_t;

static uart_tx_transaction_t uart5_tx_transaction = {0};
static uart_rx_mailbox_t uart5_rx_mailbox = {0};

static uint8_t service_reset_reason = 0U;
static uint32_t service_uptime = 0U;
static uint8_t heartbeat_counter = 0U;

static uint8_t can_fd_pad_length(uint8_t length)
{
    if (length <= 8U)  return length;
    if (length <= 12U) return 12U;
    if (length <= 16U) return 16U;
    if (length <= 20U) return 20U;
    if (length <= 24U) return 24U;
    if (length <= 32U) return 32U;
    if (length <= 48U) return 48U;
    if (length <= 64U) return 64U;

    return 0U;
}

static uint8_t identify_active = 0U;
static uint8_t identify_step = 0U;

static void identify_start(void)
{
    identify_step = 0U;
    identify_active = 1U;

    led_off(GPIOA, LED4_PIN);
}

void protocol_service_init(const reset_reason_t *reason)
{
    heartbeat_counter = 0U;
    service_uptime = 0U;

    if (reason != NULL)
    {
        service_reset_reason = reset_reason_pack(reason);
    }
    else
    {
        service_reset_reason = 0U;
    }
}

static uint8_t service_can_state_get(void)
{
    switch (can_get_state())
    {
        case CAN_STATE_WARNING:
            return SERVICE_CAN_WARNING;

        case CAN_STATE_PASSIVE:
            return SERVICE_CAN_PASSIVE;

        case CAN_STATE_BUS_OFF:
            return SERVICE_CAN_BUS_OFF;

        case CAN_STATE_ACTIVE:
        default:
            return SERVICE_CAN_ACTIVE;
    }
}

static uint8_t service_status_flags_get(void)
{
    uint8_t flags = 0U;

    if (board_info_valid() != 0U)
    {
        flags |= STATUS_READY;
    }

    if (fault_active() != 0U)
    {
        flags |= STATUS_FAULT;
    }

    switch (can_get_state())
    {
        case CAN_STATE_WARNING:
            flags |= STATUS_CAN_WARNING;
            break;

        case CAN_STATE_PASSIVE:
            flags |= STATUS_CAN_PASSIVE;
            break;

        case CAN_STATE_BUS_OFF:
            flags |= STATUS_CAN_BUS_OFF;
            break;

        case CAN_STATE_ACTIVE:
        default:
            break;
    }

    if (sync_counter != 0U)
    {
        flags |= STATUS_SYNC_SEEN;
    }

    if ((service_reset_reason & RESET_REASON_IWDG) != 0U)
    {
        flags |= STATUS_WATCHDOG_RESET;
    }

    return flags;
}

uint8_t can_protocol_process_request(const can_protocol_request_t *request, can_protocol_response_t *frame)
{
    comm_led_activity();
    uint8_t length = 0U;
    uint8_t status;

    frame->command = request->command;
    frame->sequence = request->sequence;

    switch (request->command) {
        case 0x00: // Protocol Test
        {
            frame->data[0] = 0x11;
            frame->data[1] = 0x22;
            frame->data[2] = 0x33;
            length = 3U;
            status = PROTOCOL_STATUS_OK;
            break;
        }
        case 0x01: // Identify
        {
            identify_start();
            status = PROTOCOL_STATUS_OK;
            break;
        }
        case 0x02: // Get Device Info
        {
            const board_info_t *info = board_info_get();
            if (board_info_valid())
            {
                fault_clear(FAULT_BOARD_INFO);

                frame->data[0] = (uint8_t)(info->hw_major);
                frame->data[1] = (uint8_t)(info->hw_minor);
                frame->data[2] = (uint8_t)(info->year >> 8);
                frame->data[3] = (uint8_t)(info->year);
                frame->data[4] = (uint8_t)(info->month);
                frame->data[5] = (uint8_t)(info->day); 
                frame->data[6] = (uint8_t)(info->serial_number >> 24);
                frame->data[7] = (uint8_t)(info->serial_number >> 16);
                frame->data[8] = (uint8_t)(info->serial_number >> 8);
                frame->data[9] = (uint8_t)(info->serial_number);
                frame->data[10] = (uint8_t)(info->card_type >> 8);
                frame->data[11] = (uint8_t)(info->card_type);
                frame->data[12] = (uint8_t)(fw_version.major);
                frame->data[13] = (uint8_t)(fw_version.minor);
                frame->data[14] = (uint8_t)(fw_version.patch);
                frame->data[15] = (uint8_t)(fw_version.year >> 8);
                frame->data[16] = (uint8_t)(fw_version.year);
                frame->data[17] = (uint8_t)(fw_version.month);
                frame->data[18] = (uint8_t)(fw_version.day);
                frame->data[19] = (uint8_t)(info->capabilities.flags >> 24);
                frame->data[20] = (uint8_t)(info->capabilities.flags >> 16);
                frame->data[21] = (uint8_t)(info->capabilities.flags >> 8);
                frame->data[22] = (uint8_t)(info->capabilities.flags);
                frame->data[23] = (uint8_t)(info->capabilities.relay_count); 
                frame->data[24] = (uint8_t)(info->capabilities.voltage_count);
                frame->data[25] = (uint8_t)(info->capabilities.current_count);
                frame->data[26] = (uint8_t)(info->capabilities.frequency_count);
                frame->data[27] = (uint8_t)(info->capabilities.digital_input_count);
                frame->data[28] = (uint8_t)(info->capabilities.digital_output_count);
                frame->data[29] = (uint8_t)(info->capabilities.pwm_count);
                frame->data[30] = (uint8_t)(info->capabilities.analog_output_count);
                frame->data[31] = (uint8_t)(info->capabilities.can_count);
                frame->data[32] = (uint8_t)(info->capabilities.lin_count);
                frame->data[33] = (uint8_t)(info->capabilities.uart_count);
                frame->data[34] = (uint8_t)(info->capabilities.rs485_count);
                frame->data[35] = (uint8_t)(info->capabilities.rs232_count);
                frame->data[36] = (uint8_t)(info->capabilities.i2c_count);
                frame->data[37] = (uint8_t)(info->capabilities.spi_count);
                frame->data[38] = (uint8_t)(info->slot_count);
                length = 39U;
                status = PROTOCOL_STATUS_OK;
            }
            else
            {
                fault_set(FAULT_BOARD_INFO);
                status = PROTOCOL_STATUS_ERROR;
            }
            break;
        }
        case 0x30: // I2C CONFIG
        {
            i2c_config_t config;

            if (request->length != 5U)
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            config.clock_frequency = ((uint32_t)request->data[0] << 24U) | ((uint32_t)request->data[1] << 16U) | ((uint32_t)request->data[2] << 8U) | ((uint32_t)request->data[3]);
            config.addressing_mode = request->data[4];

            if (i2c1_config(&config) == 1U)
            {
                status = PROTOCOL_STATUS_OK;
            }
            else
            {
                status = PROTOCOL_STATUS_ERROR;
            }

            length = 0U;
            break;
        }
        case 0x31: // I2C WRITE
        {
            if (request->length < 4U)
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            uint16_t addr = ((uint16_t)request->data[0] << 8U) | ((uint16_t)request->data[1]);
            uint16_t len = ((uint16_t)request->data[2] << 8U) | ((uint16_t)request->data[3]);

            if (len == 0U)
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            if ((uint16_t)request->length != (4U + len))
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            communication_status.error_flags &= ~COMM_I2C_ERROR;
            communication_status.interface_status |= COMM_I2C_BUSY;

            if (i2c1_write(addr, &request->data[4], len) != 1U)
            {
                communication_status.error_flags |= COMM_I2C_ERROR;
                communication_status.interface_status &= ~COMM_I2C_BUSY;

                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            communication_status.interface_status &= ~COMM_I2C_BUSY;

            length = 0U;
            status = PROTOCOL_STATUS_OK;
            break;
        }
        case 0x32: // I2C READ
        {
            if (request->length != 4U)
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            uint16_t addr = ((uint16_t)request->data[0] << 8U) | ((uint16_t)request->data[1]);
            uint16_t len = ((uint16_t)request->data[2] << 8U) | ((uint16_t)request->data[3]);
            if ((len == 0U) || (len > RESPONSE_PROTOCOL_MAX_PAYLOAD))
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            communication_status.error_flags &= ~COMM_I2C_ERROR;
            communication_status.interface_status |= COMM_I2C_BUSY;

            if (i2c1_read(addr, frame->data, len) != 1U)
            {
                communication_status.error_flags |= COMM_I2C_ERROR;
                communication_status.interface_status &= ~COMM_I2C_BUSY;
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            communication_status.interface_status &= ~COMM_I2C_BUSY;

            length = (uint8_t)len;
            status = PROTOCOL_STATUS_OK;
            break;
        }
        case 0x33: // I2C REG WRITE
        {
            if (request->length < 5U)
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            uint16_t addr = ((uint16_t)request->data[0] << 8U) | ((uint16_t)request->data[1]);
            uint8_t reg = request->data[2];
            uint16_t len = ((uint16_t)request->data[3] << 8U) | ((uint16_t)request->data[4]);
            if ((len == 0U) || (request->length != (uint8_t)(5U + len)))
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            communication_status.error_flags &= ~COMM_I2C_ERROR;
            communication_status.interface_status |= COMM_I2C_BUSY;

            if (i2c1_write_reg(addr, reg, &request->data[5], len) != 1U)
            {
                communication_status.error_flags |= COMM_I2C_ERROR;
                communication_status.interface_status &= ~COMM_I2C_BUSY;
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            communication_status.interface_status &= ~COMM_I2C_BUSY;

            length = 0U;
            status = PROTOCOL_STATUS_OK;
            break;
        }
        case 0x34: // I2C REG READ
        {
            if (request->length != 5U)
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            uint16_t addr = ((uint16_t)request->data[0] << 8U) | (uint16_t)request->data[1];
            uint8_t reg = request->data[2];
            uint16_t len = ((uint16_t)request->data[3] << 8U) | (uint16_t)request->data[4];

            if ((len == 0U) || (len > RESPONSE_PROTOCOL_MAX_PAYLOAD))
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            communication_status.error_flags &= ~COMM_I2C_ERROR;
            communication_status.interface_status |= COMM_I2C_BUSY;

            if (i2c1_read_reg(addr, reg, frame->data, len) != 1U)
            {
                communication_status.error_flags |= COMM_I2C_ERROR;
                communication_status.interface_status &= ~COMM_I2C_BUSY;

                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            communication_status.interface_status &= ~COMM_I2C_BUSY;

            length = (uint8_t)len;
            status = PROTOCOL_STATUS_OK;
            break;
        }
        case 0x35: // SPI CONFIG
        {
            spi_config_t config;
            if (request->length != 8U)
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            config.frequency = ((uint32_t)request->data[0] << 24U) | ((uint32_t)request->data[1] << 16U) | ((uint32_t)request->data[2] << 8U) | ((uint32_t)request->data[3]);
            config.cpol = request->data[4];
            config.cpha = request->data[5];
            config.bit_order = request->data[6];
            config.data_size = request->data[7];

            if (spi1_config(&config) == 1U)
            {
                status = PROTOCOL_STATUS_OK;
            }
            else
            {
                status = PROTOCOL_STATUS_ERROR;
            }

            length = 0U;
            break;
        }
        case 0x36: // SPI TRANSFER BYTE
        {
            if (request->length != 1U)
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            uint8_t tx = request->data[0];
            uint8_t rx;

            communication_status.error_flags &= ~COMM_SPI_ERROR;
            communication_status.interface_status |= COMM_SPI_BUSY;

            if (spi1_transfer_byte(tx, &rx) != 1U)
            {
                communication_status.error_flags |= COMM_SPI_ERROR;
                communication_status.interface_status &= ~COMM_SPI_BUSY;
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            communication_status.interface_status &= ~COMM_SPI_BUSY;

            frame->data[0] = rx;

            length = 1U;
            status = PROTOCOL_STATUS_OK;
            break;
        }
        case 0x37: // SPI TRANSFER WORD
        {
            if (request->length < 2U)
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            uint16_t len = ((uint16_t)request->data[0] << 8U) | (uint16_t)request->data[1];

            if ((len == 0U) || (len > RESPONSE_PROTOCOL_MAX_PAYLOAD) || (request->length != (uint8_t)(2U + len)))
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            communication_status.error_flags &= ~COMM_SPI_ERROR;
            communication_status.interface_status |= COMM_SPI_BUSY;

            if (spi1_transfer(&request->data[2], frame->data, len) != 1U)
            {
                communication_status.error_flags |= COMM_SPI_ERROR;
                communication_status.interface_status &= ~COMM_SPI_BUSY;

                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            communication_status.interface_status &= ~COMM_SPI_BUSY;

            length = (uint8_t)len;
            status = PROTOCOL_STATUS_OK;
            break;
        }
        case 0x38: // UART CONFIG
        {
            serial_config_t config;
            if (request->length != 7U)
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            config.baudrate = ((uint32_t)request->data[0] << 24U) | ((uint32_t)request->data[1] << 16U) | ((uint32_t)request->data[2] << 8U) | ((uint32_t)request->data[3]);
            config.data_bits = request->data[4];
            config.parity = request->data[5];
            config.stop_bits = request->data[6];

            if (uart5_config(&config) == 1U)
            {
                status = PROTOCOL_STATUS_OK;
            }
            else
            {
                status = PROTOCOL_STATUS_ERROR;
            }

            length = 0U;
            break;
        }
        case 0x39: // UART WRITE
        {
            if ((request->length == 0U) || (request->length > UART5_TX_BUFFER_SIZE))
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            if (uart5_tx_transaction.active != 0U)
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            uart5_tx_transaction.active = 1U;
            uart5_tx_transaction.sequence = request->sequence;

            if (uart5_dma_write(request->data, request->length) == 0U)
            {
                uart5_tx_transaction = (uart_tx_transaction_t){0};
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            return 0U;
        }
        case 0x3A: // UART READ
        {
            if (request->length != 0U)
            {
                status = PROTOCOL_STATUS_ERROR;
                break;
            }

            if (uart5_rx_mailbox.ready == 0U)
            {
                length = 0U;
                status = PROTOCOL_STATUS_OK;
                break;
            }

            uint16_t rx_length = uart5_rx_mailbox.length;

            if (rx_length > RESPONSE_PROTOCOL_MAX_PAYLOAD)
            {
                rx_length = RESPONSE_PROTOCOL_MAX_PAYLOAD;
            }

            for (uint16_t i = 0U; i < rx_length; i++)
            {
                frame->data[i] = uart5_rx_mailbox.data[i];
            }

            length = (uint8_t)rx_length;
            status = PROTOCOL_STATUS_OK;

            uart5_rx_mailbox.ready = 0U;
            uart5_rx_mailbox.length = 0U;

            break;
        }
        default:
        {
            status = PROTOCOL_STATUS_ERROR;
            break;
        }
    }

    frame->length = length;
    frame->status = status;

    return (uint8_t)(4U + length);
}

void can_process_response(const can_protocol_request_t *request, uint8_t can_length)
{
    can_protocol_response_t response = {0};

    if (can_length < 3U)
    {
        return;
    }

    if (request->length > REQUEST_PROTOCOL_MAX_PAYLOAD)
    {
        return;
    }

    uint8_t protocol_length = (uint8_t)(3U + request->length);

    if (protocol_length > can_length)
    {
        return;
    }

    uint8_t response_length = can_protocol_process_request(request, &response);
    uint8_t fd_length = can_fd_pad_length(response_length);

    if (fd_length != 0U)
    {
        can_send_fd(can_id_make(slot_id, 0x01U), (const uint8_t *)&response, fd_length);
    }
}

static uint8_t communication_send_response(
    const can_protocol_response_t *response)
{
    if (response == NULL)
    {
        return 0U;
    }

    uint8_t protocol_length = (uint8_t)(4U + response->length);
    uint8_t fd_length = can_fd_pad_length(protocol_length);

    if (fd_length == 0U)
    {
        return 0U;
    }

    return can_send_fd(can_id_make(slot_id, 0x01U), (const uint8_t *)response, fd_length);
}

// Service Cyclic Frames
static uint8_t send_frame_0xX10(void)
{
    service_status_t status = {0};

    status.heartbeat_counter = heartbeat_counter;
    status.status_flags = service_status_flags_get();
    status.fault_flags = fault_get();
    status.reset_reason = service_reset_reason;
    status.can_state = service_can_state_get();
    status.uptime = service_uptime;
    status.protocol_major = PROTOCOL_VERSION_MAJOR;
    status.protocol_minor = PROTOCOL_VERSION_MINOR;

    uint8_t data_can[12] = {0};

    data_can[0]  = status.heartbeat_counter;
    data_can[1]  = status.status_flags;
    data_can[2]  = (uint8_t)(status.fault_flags >> 8U);
    data_can[3]  = (uint8_t)status.fault_flags;
    data_can[4]  = status.reset_reason;
    data_can[5]  = status.can_state;
    data_can[6]  = (uint8_t)(status.uptime >> 24U);
    data_can[7]  = (uint8_t)(status.uptime >> 16U);
    data_can[8]  = (uint8_t)(status.uptime >> 8U);
    data_can[9]  = (uint8_t)status.uptime;
    data_can[10] = status.protocol_major;
    data_can[11] = status.protocol_minor;

    heartbeat_counter++;

    return can_send_fd(can_id_make(slot_id, 0x10U), data_can, sizeof(data_can));
}
// END Service Cyclic Frames

// Communication Board Cyclic Frames
static uint8_t send_frame_0xX20(void)
{

    uint8_t data_can[2];

    data_can[0] = 0U;
    data_can[1] = 0U;

    return can_send_fd(can_id_make(slot_id, 0x20U), data_can, sizeof(data_can));
}
// END Communication Board Cyclic Frames

void can_send_100ms_frames(void)
{
    static uint8_t slot = 0U;
    uint8_t sent = 0U;

    switch (slot)
    {
        case 0:
            sent = send_frame_0xX20();
            break;
        default:
            slot = 0U;
            break;
    }

    if (sent != 0U)
    {
        slot++;

        if (slot >= 1U)
        {
            slot = 0U;
        }
    }
}

void can_send_1s_frames(void)
{
    static uint8_t slot = 0U;
    uint8_t sent = 0U;

    service_uptime++;

    switch (slot)
    {
        case 0:
            sent = send_frame_0xX10();
            break;
        default:
            slot = 0U;
            break;
    }

    if (sent != 0U)
    {
        slot++;

        if (slot >= 1U)
        {
            slot = 0U;
        }
    }
}

void identify_process(void)
{
    led_off(GPIOA, LED4_PIN);

    if (identify_step >= 12U)
    {
        identify_active = 0U;
        identify_step = 0U;
        return;
    }

    if ((identify_step & 0x01U) == 0U)
    {
        led_on(GPIOA, LED4_PIN);
    }

    identify_step++;
}

void uart5_tx_callback(uint8_t tx_status)
{
    if (uart5_tx_transaction.active == 0U)
    {
        return;
    }

    can_protocol_response_t response = {0};

    response.command = 0x39U;
    response.sequence = uart5_tx_transaction.sequence;
    response.status = (tx_status != 0U) ? PROTOCOL_STATUS_OK : PROTOCOL_STATUS_ERROR;
    response.length = 0U;

    if (communication_send_response(&response) != 0U)
    {
        uart5_tx_transaction = (uart_tx_transaction_t){0};
    }

    uart5_tx_transaction = (uart_tx_transaction_t){0};
}

void uart5_rx_callback(const uint8_t *data, uint16_t length)
{
    if ((data == NULL) || (length == 0U))
    {
        return;
    }

    if (uart5_rx_mailbox.ready != 0U)
    {
        return;
    }

    if (length > RESPONSE_PROTOCOL_MAX_PAYLOAD)
    {
        length = RESPONSE_PROTOCOL_MAX_PAYLOAD;
    }

    uart5_rx_mailbox.length = length;

    for (uint16_t i = 0U; i < length; i++)
    {
        uart5_rx_mailbox.data[i] = data[i];
    }

    uart5_rx_mailbox.ready = 1U;
}