#ifndef FAULT_H
#define FAULT_H

#include <stdint.h>

#define FAULT_PIN 8U // PA8

#define FAULT_NONE              0x0000U
#define FAULT_BOARD_INFO        0x0001U
#define FAULT_INTERNAL          0x0020U
#define FAULT_INA               0x0075U
#define FAULT_VIN_LINE          0x0076U
#define FAULT_12V_LINE          0x0077U
#define FAULT_5V_LINE           0x0078U
#define FAULT_3V3_LINE          0x0079U

void fault_pin_init(void);
uint16_t fault_get(void);
uint8_t fault_active(void);
void fault_set(uint16_t fault);
void fault_clear(uint16_t fault);

#endif // FAULT_H